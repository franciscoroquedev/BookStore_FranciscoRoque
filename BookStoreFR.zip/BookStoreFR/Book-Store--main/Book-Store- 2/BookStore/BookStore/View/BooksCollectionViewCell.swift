//
//  BooksCollectionViewCell.swift
//  BookStore
//
//  Created by itsector on 30/04/2021.
//

import UIKit

class BooksCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imgView: UIImageView!
    //this contraint help to define 2 columns
    @IBOutlet weak var imgViewWidthConst: NSLayoutConstraint!
    
}
