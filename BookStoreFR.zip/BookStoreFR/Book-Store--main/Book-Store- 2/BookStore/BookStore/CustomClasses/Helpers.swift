//
//  Helpers.swift
//  BookStore
//
//  Created by Arslan Khan on 09/05/2021.
//

import Foundation

class Helper {
    static let shared = Helper()
    var bookItems = [Items]()
}
