//
//  PersistenceManager.swift
//  BookStore
//
//  Created by itsector on 03/05/2021.
//

import Foundation

enum PersistenceActionType {
    case add, remove
}

//    static private let defaults = UserDefaults.standard
//    enum Keys { static let favorits = "favorites" }
//
//
//static func updateWith(favorite: Book, actionType: PersistenceActionType, completed: @escaping (BSError?) -> Void) {
//    
//}
