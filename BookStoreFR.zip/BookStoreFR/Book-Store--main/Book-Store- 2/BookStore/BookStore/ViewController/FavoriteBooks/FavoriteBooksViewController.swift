//
//  FavoriteBooksViewController.swift
//  BookStore
//
//  Created by Arslan Khan on 09/05/2021.
//

import UIKit

class FavoriteBooksViewController: UIViewController {
    @IBOutlet weak var collectionView: UICollectionView!
    var items: [Items] = []
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        getFavoriteBooks()
    }
    
    func getFavoriteBooks() {
        var favItem: [Items] = []
        for item in Helper.shared.bookItems {
            if UserDefaults.standard.bool(forKey: item.id){
                favItem.append(item)
            }
        }
        items = favItem
        collectionView.reloadData()
    }
    
    func gotoDetailScreen(_ bookItem: Items) {
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "BookDetailViewController") as! BookDetailViewController
        vc.bookItem = bookItem
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

extension FavoriteBooksViewController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let item = items[indexPath.item]
        gotoDetailScreen(item)
    }
}

extension FavoriteBooksViewController: UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return items.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "BookCollectionViewCell", for: indexPath) as! BooksCollectionViewCell
        let item = items[indexPath.item]
        cell.imgViewWidthConst.constant = (collectionView.frame.width / 2) - 10
        if let thumbnail = item.volumeInfo.imageLinks?.thumbnail {
            cell.imgView.loadImageUsingCache(withUrl: thumbnail)
        } else {
            cell.imgView.image = UIImage(named: "empty")
        }
        return cell
        
    }
}
