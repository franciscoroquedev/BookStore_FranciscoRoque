//
//  BookDetailViewController.swift
//  BookStore
//
//  Created by itsector on 03/05/2021.
//

import UIKit

class BookDetailViewController: UIViewController {
    var bookItem: Items?
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var titleLbl: UILabel!
    @IBOutlet weak var authorLbl: UILabel!
    @IBOutlet weak var detailsLbl: UILabel!
    @IBOutlet weak var favoritebtn: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        populateDetails()
        setFavBtn(UserDefaults.standard.bool(forKey: bookItem?.id ?? ""))
    }
    @IBAction func didTapBuyBtn(_ sender: Any) {
      openBuyLink()
    }
    
    @IBAction func didTappedFavBtn(_ sender: UIButton) {
        let isFav = sender.tag == 0
        UserDefaults.standard.set(isFav, forKey: bookItem?.id ?? "")
        setFavBtn(isFav)
    }
    
    func setFavBtn(_ isFav:Bool) {
        if isFav {
            favoritebtn.tag = 1
            favoritebtn.setTitle("Marked Favorite", for: .normal)
            favoritebtn.backgroundColor = .systemGreen
        } else {
            favoritebtn.tag = 0
            favoritebtn.setTitle("Add To Favorite", for: .normal)
            favoritebtn.backgroundColor = .systemBlue
        }
    }
    
    func openBuyLink() {
        if let item = bookItem, let url = URL(string:item.saleInfo.buyLink ?? "" ) {
            UIApplication.shared.open(url)
        } else {
            DispatchQueue.main.async {
                let alert = UIAlertController(title: "Sorry", message: "This item is not available yet" , preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
        }
    }
    
    func populateDetails() {
        guard let data = bookItem else { return }
        if let url = data.volumeInfo.imageLinks?.thumbnail {
            imgView.loadImageUsingCache(withUrl: url)
        }
        titleLbl.text = data.volumeInfo.title
        authorLbl.text = data.volumeInfo.authors?.joined(separator: "\n")
        detailsLbl.text = data.volumeInfo.description
    }
    
    //MARK: - Actions
    
    @objc private func favouriteButtonTapped() {
        
    }
}
